from flask import Flask, render_template, request, redirect, url_for

# Creating the Flask app
app = Flask(__name__)

# This dictionary will store registered users' email, name, and password
users = {}

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email'].strip().lower()
        password = request.form['password']

        # Checking if user exists and password is correct
        if email in users and users[email]['password'] == password:
            return render_template('welcome.html', name=users[email]['name'])
        else:
            return "<h2 style='color:red; text-align:center;'>Invalid credentials or user not registered!</h2>"

    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email'].strip().lower()
        password = request.form['password']

        if email not in users:
            users[email] = {'name': name, 'password': password}
            return redirect(url_for('login'))
        else:
            return "<h2 style='color:red; text-align:center;'>User already exists!</h2>"

    return render_template('register.html')


if __name__ == '__main__':
    app.run(debug=True)


